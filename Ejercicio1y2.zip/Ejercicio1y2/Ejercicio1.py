#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def contar_palabras(cadena):
    # Elimina los espacios en blanco adicionales al principio y al final de la cadena
    cadena = cadena.strip()
    # Divide la cadena en palabras utilizando los espacios en blanco como separadores
    palabras = cadena.split()
    # Filtra las palabras que no contengan caracteres numéricos
    palabras_sin_numeros = [palabra for palabra in palabras if not any(caracter.isdigit() for caracter in palabra)]
    # Retorna la cantidad de palabras sin números
    return len(palabras_sin_numeros)


while True:
    # Solicita al usuario que ingrese una cadena de texto
    entrada = input("Ingrese una cadena (o presione Enter para salir): ")

    # Si el usuario presiona Enter sin ingresar una cadena, se rompe el bucle
    if entrada == "":
        break

    # Llama a la función contar_palabras para contar las palabras sin números en la cadena ingresada
    numero_palabras = contar_palabras(entrada)

    # Imprime el resultado
    print("Número de palabras sin números:", numero_palabras)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




