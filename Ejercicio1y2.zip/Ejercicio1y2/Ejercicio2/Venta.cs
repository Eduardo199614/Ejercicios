﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeraAplicacion
{
    internal class Venta
    {
        public double Monto { get; set; }
        public bool Cobrada { get; set; }

        public Venta(double monto, bool cobrada)
        {
            Monto = monto;
            Cobrada = cobrada;
        }

    }
}
