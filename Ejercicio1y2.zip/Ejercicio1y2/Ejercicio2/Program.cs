﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeraAplicacion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool agregarCliente = true;

            while (agregarCliente)
            {
                // Crear instancia de Cliente
                Cliente cliente = new Cliente("");

                // Capturar nombre del cliente
                Console.Write("Ingrese el nombre del cliente: ");
                string nombreCliente = Console.ReadLine();
                cliente.Nombre = nombreCliente;

                // Capturar deudas del cliente
                Console.WriteLine("Ingrese las deudas del cliente (ingrese '0' para finalizar):");
                double deuda;
                string inputDeuda;
                do
                {
                    Console.Write("Ingrese el monto de la deuda: ");
                    inputDeuda = Console.ReadLine();

                    if (Double.TryParse(inputDeuda, out deuda) && deuda != 0)
                    {
                        cliente.AgregarDeuda(deuda);
                    }
                    else if (deuda == 0)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Valor de deuda inválido. Intente nuevamente.");
                    }
                } while (true);

                // Calcular el monto total de las deudas vencidas (considerando 30 días de vencimiento)
                int diasVencimiento = 30;
                double totalDeudasVencidas = cliente.CalcularDeudasVencidas(diasVencimiento);

                // Calcular el total de cobros
                double totalCobros = cliente.CalcularTotalCobros();

                // Mostrar resultados
                Console.WriteLine();
                Console.WriteLine("Cliente: " + cliente.Nombre);
                Console.WriteLine("Monto total de las deudas vencidas (con " + diasVencimiento + " días de vencimiento): $" + totalDeudasVencidas);
                Console.WriteLine("Total de cobros: $" + totalCobros);

                // Preguntar si desea agregar deudas a otro cliente
                Console.WriteLine();
                Console.Write("¿Desea agregar deudas a otro cliente? (S/N): ");
                string respuesta = Console.ReadLine();

                if (respuesta.ToLower() != "s")
                {
                    agregarCliente = false;
                }

                Console.WriteLine();
                //Console.ReadLine();
            }
        }
    }
}
