﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeraAplicacion
{
    internal class Cliente
    {
        //Instanciamos las variables
        private string nombre;
        private List<double> deudas;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public Cliente(string nombre)
        {
            this.nombre = nombre;
            this.deudas = new List<double>();
        }

        public void AgregarDeuda(double monto)
        {
            deudas.Add(monto);
        }

        public double CalcularDeudasVencidas(int diasVencimiento)
        {
            double totalDeudasVencidas = 0;
            DateTime fechaActual = DateTime.Now;

            foreach (double deuda in deudas)
            {
                // Simulamos que la deuda se vence después de ciertos días
                DateTime fechaVencimiento = fechaActual.AddDays(-diasVencimiento);

                // Si la deuda está vencida, se suma al total
                if (fechaVencimiento < fechaActual)
                {
                    totalDeudasVencidas += deuda;
                }
            }

            return totalDeudasVencidas;
        }

        public double CalcularTotalCobros()
        {
            double totalCobros = 0;

            foreach (double deuda in deudas)
            {
                totalCobros += deuda;
            }

            return totalCobros;
        }
    }


}

